import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[var(--neu-bg-secondary)] pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-[var(--neu-accent)]">IQRA CLASSES</h3>
            <p className="text-[var(--neu-text-secondary)]">Excellence in Board Education. Building strong foundations for future success.</p>
            <div className="flex gap-4">
              <a href="#" className="neu-btn p-2"><Facebook size={18} /></a>
              <a href="#" className="neu-btn p-2"><Twitter size={18} /></a>
              <a href="#" className="neu-btn p-2"><Instagram size={18} /></a>
              <a href="#" className="neu-btn p-2"><Youtube size={18} /></a>
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><Link to="/" className="text-[var(--neu-text-secondary)] hover:text-[var(--neu-accent)]">Home</Link></li>
              <li><Link to="/#courses" className="text-[var(--neu-text-secondary)] hover:text-[var(--neu-accent)]">Courses</Link></li>
              <li><Link to="/notes" className="text-[var(--neu-text-secondary)] hover:text-[var(--neu-accent)]">Notes</Link></li>
              <li><Link to="/solutions" className="text-[var(--neu-text-secondary)] hover:text-[var(--neu-accent)]">Solutions</Link></li>
              <li><Link to="/quiz" className="text-[var(--neu-text-secondary)] hover:text-[var(--neu-accent)]">Quiz</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Courses</h4>
            <ul className="space-y-3">
              <li><Link to="/#courses" className="text-[var(--neu-text-secondary)] hover:text-[var(--neu-accent)]">Class 11 & 12</Link></li>
              <li><Link to="/#courses" className="text-[var(--neu-text-secondary)] hover:text-[var(--neu-accent)]">Class 9 & 10</Link></li>
              <li><Link to="/#courses" className="text-[var(--neu-text-secondary)] hover:text-[var(--neu-accent)]">Class 6, 7 & 8</Link></li>
              <li><Link to="/#courses" className="text-[var(--neu-text-secondary)] hover:text-[var(--neu-accent)]">Class 2, 3, 4 & 5</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Contact Info</h4>
            <p className="text-[var(--neu-text-secondary)] mb-2">New Jaganpura Double Transformer, Patna - 800027</p>
            <p className="text-[var(--neu-text-secondary)] mb-2">Phone: +91 8228023255</p>
            <p className="text-[var(--neu-text-secondary)]">Email: iqraclasses351@gmail.com</p>
          </div>
        </div>
        <div className="border-t border-[var(--neu-shadow-dark)] pt-8 text-center text-[var(--neu-text-secondary)] text-sm">
          <p>&copy; {new Date().getFullYear()} IQRA CLASSES. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
