import React from 'react';
import { motion } from 'motion/react';
import { BookOpen, Users, Award, CheckCircle, Phone, Mail, MapPin } from 'lucide-react';

export default function Home() {
  const stats = [
    { label: 'Students Trained', value: '2000+', icon: <Users className="text-blue-500" /> },
    { label: 'Success Rate', value: '95%', icon: <Award className="text-yellow-500" /> },
    { label: 'Years Experience', value: '9+', icon: <BookOpen className="text-green-500" /> },
  ];

  const courses = [
    { class: 'Class 2', fee: '₹8,000', subjects: ['Hindi', 'English', 'Math', 'EVS'] },
    { class: 'Class 3', fee: '₹9,000', subjects: ['Hindi', 'English', 'Math', 'EVS'] },
    { class: 'Class 4', fee: '₹10,000', subjects: ['Hindi', 'English', 'Math', 'EVS'] },
    { class: 'Class 5', fee: '₹11,000', subjects: ['Hindi', 'English', 'Math', 'EVS'] },
    { class: 'Class 6', fee: '₹12,000', subjects: ['Hindi', 'English', 'Math', 'Science', 'S.St', 'Sanskrit'] },
    { class: 'Class 7', fee: '₹13,000', subjects: ['Hindi', 'English', 'Math', 'Science', 'S.St', 'Sanskrit'] },
    { class: 'Class 8', fee: '₹14,000', subjects: ['Hindi', 'English', 'Math', 'Science', 'S.St', 'Sanskrit'] },
    { class: 'Class 9', fee: '₹15,000', subjects: ['Hindi', 'English', 'Math', 'Science', 'S.St', 'Sanskrit'] },
    { class: 'Class 10', fee: '₹16,000', subjects: ['Hindi', 'English', 'Math', 'Science', 'S.St', 'Sanskrit'] },
    { class: 'Class 11', fee: '₹18,000', subjects: ['Physics', 'Chemistry', 'Math', 'Biology', 'English', 'Hindi'] },
    { class: 'Class 12', fee: '₹20,000', subjects: ['Physics', 'Chemistry', 'Math', 'Biology', 'English', 'Hindi'] },
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section id="home" className="py-20 bg-[var(--neu-bg-primary)]">
        <div className="container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Excel in Board Exams with <span className="text-[var(--neu-accent)]">IQRA CLASSES</span>
            </h1>
            <p className="text-lg text-[var(--neu-text-secondary)] mb-8 max-w-lg">
              Leading coaching institute for Classes 2-12 with expert faculty, proven results, and personalized attention for every student.
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="neu-btn neu-btn-primary px-8 py-3 text-lg">Enroll Now</button>
              <button className="neu-btn px-8 py-3 text-lg">View Courses</button>
            </div>
            <div className="mt-12 flex gap-8">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <span className="block text-2xl font-bold text-[var(--neu-accent)]">{stat.value}</span>
                  <span className="text-sm text-[var(--neu-text-secondary)]">{stat.label}</span>
                </div>
              ))}
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="hidden md:flex justify-center"
          >
            <div className="w-full max-w-md aspect-square bg-[var(--neu-bg-secondary)] rounded-[40px] shadow-[var(--neu-shadow-large)] flex flex-col items-center justify-center gap-4 p-8">
              <span className="text-8xl">📚</span>
              <p className="text-2xl font-bold text-center">Welcome To IQRA Classes</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-[var(--neu-bg-secondary)]">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Why Choose IQRA CLASSES?</h2>
            <p className="text-[var(--neu-text-secondary)] max-w-2xl mx-auto">We provide comprehensive education solutions tailored for Board students.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: '👨‍🏫', title: 'Expert Faculty', desc: 'Experienced teachers with deep knowledge of Board curriculum.' },
              { icon: '👥', title: 'Small Batch Size', desc: 'Maximum 25 students per batch ensuring personalized attention.' },
              { icon: '📝', title: 'Regular Assessments', desc: 'Weekly tests and monthly examinations to track progress.' },
              { icon: '❓', title: 'Doubt Sessions', desc: 'Dedicated sessions and one-on-one mentoring for difficult concepts.' },
              { icon: '📚', title: 'Study Materials', desc: 'Comprehensive notes and practice papers aligned with syllabus.' },
              { icon: '👨‍👩‍👧‍👦', title: 'Parent Updates', desc: 'Regular communication about student progress and performance.' },
            ].map((feature) => (
              <div key={feature.title} className="neu-card text-center">
                <div className="text-5xl mb-6">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-[var(--neu-text-secondary)]">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="courses" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Our Courses</h2>
            <p className="text-[var(--neu-text-secondary)]">Comprehensive coaching for Board Classes 2-12</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {courses.map((course) => (
              <div key={course.class} className="neu-card flex flex-col h-full">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-bold">{course.class}</h3>
                  <span className="text-[var(--neu-accent)] font-bold">{course.fee}</span>
                </div>
                <div className="flex flex-wrap gap-2 mb-6 flex-grow">
                  {course.subjects.map((sub) => (
                    <span key={sub} className="text-xs bg-[var(--neu-bg-secondary)] px-2 py-1 rounded-lg shadow-[var(--neu-shadow-small)]">
                      {sub}
                    </span>
                  ))}
                </div>
                <button className="neu-btn neu-btn-primary w-full mt-auto">Enroll Now</button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-[var(--neu-bg-secondary)]">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Get in Touch</h2>
            <p className="text-[var(--neu-text-secondary)]">Contact us for admissions, queries, or more information.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-8">
              <div className="flex gap-4 items-start">
                <div className="neu-btn p-3"><MapPin className="text-[var(--neu-accent)]" /></div>
                <div>
                  <h3 className="font-bold">Address</h3>
                  <p className="text-[var(--neu-text-secondary)]">New Jaganpura Double Transformer, Near Tridev mandir, Patna - 800027</p>
                </div>
              </div>
              <div className="flex gap-4 items-start">
                <div className="neu-btn p-3"><Phone className="text-[var(--neu-accent)]" /></div>
                <div>
                  <h3 className="font-bold">Phone</h3>
                  <p className="text-[var(--neu-text-secondary)]">+91 8228023255</p>
                </div>
              </div>
              <div className="flex gap-4 items-start">
                <div className="neu-btn p-3"><Mail className="text-[var(--neu-accent)]" /></div>
                <div>
                  <h3 className="font-bold">Email</h3>
                  <p className="text-[var(--neu-text-secondary)]">iqraclasses351@gmail.com</p>
                </div>
              </div>
            </div>
            <div className="neu-card">
              <form className="space-y-4">
                <div>
                  <label className="form-label">Full Name</label>
                  <input type="text" className="neu-input w-full" placeholder="Enter your name" />
                </div>
                <div>
                  <label className="form-label">Email</label>
                  <input type="email" className="neu-input w-full" placeholder="Enter your email" />
                </div>
                <div>
                  <label className="form-label">Message</label>
                  <textarea className="neu-input w-full h-32" placeholder="How can we help you?"></textarea>
                </div>
                <button className="neu-btn neu-btn-primary w-full py-3">Send Message</button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
