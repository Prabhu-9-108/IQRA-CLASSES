import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, XCircle, ChevronRight, RotateCcw } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: string[];
  correct: number;
}

const QUIZ_DATA: Record<string, Record<string, Question[]>> = {
  "Class 12": {
    "Physics": [
      { id: 1, question: "What is the unit of electric flux?", options: ["Volt-meter", "Weber", "Tesla", "Ohm-meter"], correct: 0 },
      { id: 2, question: "The speed of light in vacuum is:", options: ["3x10^8 m/s", "2x10^8 m/s", "3x10^7 m/s", "3x10^6 m/s"], correct: 0 },
    ],
    "Mathematics": [
      { id: 1, question: "The derivative of sin(x) is:", options: ["cos(x)", "-cos(x)", "tan(x)", "sec(x)"], correct: 0 },
    ]
  },
  "Class 11": {
    "Physics": [
      { id: 1, question: "Which of the following is a scalar quantity?", options: ["Velocity", "Force", "Work", "Acceleration"], correct: 2 },
    ]
  },
  "Class 10": {
    "Science": [
      { id: 1, question: "What is the chemical formula of common salt?", options: ["NaCl", "KCl", "MgCl2", "CaCl2"], correct: 0 },
      { id: 2, question: "Which lens is used to correct myopia?", options: ["Convex", "Concave", "Bifocal", "Cylindrical"], correct: 1 },
      { id: 3, question: "What is the SI unit of electric current?", options: ["Volt", "Ohm", "Ampere", "Watt"], correct: 2 },
    ],
    "Mathematics": [
      { id: 1, question: "What is the value of sin 90°?", options: ["0", "1/2", "1", "Undefined"], correct: 2 },
      { id: 2, question: "The sum of the first 10 natural numbers is:", options: ["45", "50", "55", "60"], correct: 2 },
    ]
  },
  "Class 9": {
    "Science": [
      { id: 1, question: "The cell wall of fungi is made of:", options: ["Cellulose", "Chitin", "Pectin", "Lignin"], correct: 1 },
      { id: 2, question: "Unit of acceleration is:", options: ["m/s", "m/s²", "km/h", "kg m/s"], correct: 1 },
    ]
  },
  "Class 8": {
    "Mathematics": [
      { id: 1, question: "What is the square root of 64?", options: ["6", "7", "8", "9"], correct: 2 },
    ]
  },
  "Class 7": {
    "Science": [
      { id: 1, question: "Which part of the plant carries out photosynthesis?", options: ["Root", "Stem", "Leaf", "Flower"], correct: 2 },
    ]
  },
  "Class 6": {
    "Mathematics": [
      { id: 1, question: "Which is the smallest prime number?", options: ["0", "1", "2", "3"], correct: 2 },
    ]
  },
  "Class 5": {
    "Mathematics": [
      { id: 1, question: "What is 1/2 + 1/2?", options: ["1/4", "1", "2/4", "0"], correct: 1 },
    ]
  },
  "Class 4": {
    "Mathematics": [
      { id: 1, question: "How many sides does a pentagon have?", options: ["4", "5", "6", "8"], correct: 1 },
    ]
  },
  "Class 3": {
    "Mathematics": [
      { id: 1, question: "What is 100 x 0?", options: ["100", "10", "1", "0"], correct: 3 },
    ]
  },
  "Class 2": {
    "English": [
      { id: 1, question: "Which is a vowel?", options: ["B", "C", "A", "D"], correct: 2 },
    ],
    "Mathematics": [
      { id: 1, question: "In the number 456, what is the place value of 4?", options: ["Ones", "Tens", "Hundreds", "Thousands"], correct: 2 },
      { id: 2, question: "What is the sum of 45 and 23?", options: ["68", "78", "58", "65"], correct: 0 },
      { id: 3, question: "What is 89 minus 34?", options: ["55", "45", "65", "54"], correct: 0 },
      { id: 4, question: "5 groups of 3 is equal to:", options: ["15", "10", "8", "12"], correct: 0 },
      { id: 5, question: "Which shape has 3 sides and 3 corners?", options: ["Square", "Circle", "Triangle", "Rectangle"], correct: 2 },
      { id: 6, question: "How many months are there in a year?", options: ["10", "11", "12", "13"], correct: 2 },
      { id: 7, question: "Two 10 rupee notes make how many rupees?", options: ["10", "20", "30", "40"], correct: 1 },
      { id: 8, question: "Which number is greater than 456?", options: ["450", "465", "444", "456"], correct: 1 },
      { id: 9, question: "Which unit is used to measure the length of a pencil?", options: ["Kilogram", "Litre", "Centimetre", "Metre"], correct: 2 },
      { id: 10, question: "Complete the pattern: 2, 4, 6, 8, __", options: ["9", "10", "11", "12"], correct: 1 },
      { id: 11, question: "What is the ordinal number for 10?", options: ["9th", "10th", "11th", "7th"], correct: 1 },
      { id: 12, question: "Which is heavier: An apple or a watermelon?", options: ["Apple", "Watermelon", "Both same", "None"], correct: 1 },
      { id: 13, question: "How many days are there in a week?", options: ["5", "6", "7", "8"], correct: 2 },
      { id: 14, question: "What is 100 + 50 + 4?", options: ["1054", "154", "145", "514"], correct: 1 },
      { id: 15, question: "A cube has how many faces?", options: ["4", "6", "8", "12"], correct: 1 }
    ]
  }
};

export default function Quiz() {
  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  const classes = Object.keys(QUIZ_DATA);
  const subjects = selectedClass ? Object.keys(QUIZ_DATA[selectedClass]) : [];
  const questions = (selectedClass && selectedSubject) ? QUIZ_DATA[selectedClass][selectedSubject] : [];

  const handleOptionClick = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);
    if (index === questions[currentQuestionIndex].correct) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setShowResult(true);
    }
  };

  const resetQuiz = () => {
    setSelectedClass(null);
    setSelectedSubject(null);
    setCurrentQuestionIndex(0);
    setScore(0);
    setShowResult(false);
    setSelectedOption(null);
    setIsAnswered(false);
  };

  return (
    <div className="pt-24 pb-12 min-h-screen container mx-auto px-4">
      <div className="max-w-3xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-4">Interactive Quiz</h1>
          <p className="text-[var(--neu-text-secondary)]">Test your knowledge with class-wise practice tests.</p>
        </header>

        {!selectedClass ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {classes.map((cls) => (
              <button
                key={cls}
                onClick={() => setSelectedClass(cls)}
                className="neu-card text-left hover:scale-[1.02] transition-transform"
              >
                <h3 className="text-xl font-bold text-[var(--neu-accent)]">{cls}</h3>
                <p className="text-sm text-[var(--neu-text-secondary)] mt-2">Start practice for {cls}</p>
              </button>
            ))}
          </div>
        ) : !selectedSubject ? (
          <div>
            <button onClick={() => setSelectedClass(null)} className="mb-6 text-[var(--neu-accent)] flex items-center gap-2">
              <RotateCcw size={16} /> Back to Classes
            </button>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {subjects.map((sub) => (
                <button
                  key={sub}
                  onClick={() => setSelectedSubject(sub)}
                  className="neu-card text-left hover:scale-[1.02] transition-transform"
                >
                  <h3 className="text-xl font-bold">{sub}</h3>
                  <p className="text-sm text-[var(--neu-text-secondary)] mt-2">{QUIZ_DATA[selectedClass][sub].length} Questions</p>
                </button>
              ))}
            </div>
          </div>
        ) : showResult ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="neu-card text-center py-12"
          >
            <h2 className="text-3xl font-bold mb-4">Quiz Completed!</h2>
            <div className="flex justify-center items-center gap-8 mb-8">
              <div className="text-center">
                <div className="text-5xl font-bold text-[var(--neu-accent)] mb-1">
                  {score} / {questions.length}
                </div>
                <p className="text-sm text-[var(--neu-text-secondary)]">Score</p>
              </div>
              <div className="w-px h-16 bg-[var(--neu-shadow-dark)] opacity-30"></div>
              <div className="text-center">
                <div className="text-5xl font-bold text-[var(--neu-accent)] mb-1">
                  {Math.round((score / questions.length) * 100)}%
                </div>
                <p className="text-sm text-[var(--neu-text-secondary)]">Percentage</p>
              </div>
              <div className="w-px h-16 bg-[var(--neu-shadow-dark)] opacity-30"></div>
              <div className="text-center">
                <div className="text-5xl font-bold text-[var(--neu-accent)] mb-1">
                  {((pct) => {
                    if (pct >= 90) return "A+";
                    if (pct >= 80) return "A";
                    if (pct >= 70) return "B";
                    if (pct >= 60) return "C";
                    return "D";
                  })(Math.round((score / questions.length) * 100))}
                </div>
                <p className="text-sm text-[var(--neu-text-secondary)]">Grade</p>
              </div>
            </div>
            <p className="text-lg mb-8 text-[var(--neu-text-secondary)]">
              {score === questions.length ? "Perfect Score! Excellent work." : score > questions.length / 2 ? "Good job! Keep practicing." : "Keep studying and try again."}
            </p>
            <button onClick={resetQuiz} className="neu-btn neu-btn-primary flex items-center gap-2 mx-auto">
              <RotateCcw size={18} /> Try Another Quiz
            </button>
          </motion.div>
        ) : (
          <div className="neu-card">
            <div className="flex justify-between items-center mb-8">
              <span className="text-sm font-bold text-[var(--neu-accent)] bg-[var(--neu-bg-secondary)] px-3 py-1 rounded-full">
                Question {currentQuestionIndex + 1} of {questions.length}
              </span>
              <span className="text-sm text-[var(--neu-text-secondary)]">{selectedClass} - {selectedSubject}</span>
            </div>

            <h2 className="text-xl font-bold mb-8">{questions[currentQuestionIndex].question}</h2>

            <div className="space-y-4">
              {questions[currentQuestionIndex].options.map((option, index) => {
                const isCorrect = index === questions[currentQuestionIndex].correct;
                const isSelected = selectedOption === index;
                
                let buttonClass = "neu-btn w-full text-left py-4 px-6 flex justify-between items-center";
                if (isAnswered) {
                  if (isCorrect) buttonClass += " bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 shadow-none border-2 border-green-500";
                  else if (isSelected) buttonClass += " bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 shadow-none border-2 border-red-500";
                } else if (isSelected) {
                  buttonClass += " shadow-[var(--neu-shadow-inset)] text-[var(--neu-accent)]";
                }

                return (
                  <button
                    key={index}
                    onClick={() => handleOptionClick(index)}
                    disabled={isAnswered}
                    className={buttonClass}
                  >
                    <span>{option}</span>
                    {isAnswered && isCorrect && <CheckCircle2 size={20} className="text-green-500" />}
                    {isAnswered && isSelected && !isCorrect && <XCircle size={20} className="text-red-500" />}
                  </button>
                );
              })}
            </div>

            <div className="mt-12 flex justify-end">
              <button
                onClick={handleNext}
                disabled={!isAnswered}
                className="neu-btn neu-btn-primary flex items-center gap-2 disabled:opacity-50"
              >
                {currentQuestionIndex === questions.length - 1 ? "Finish" : "Next Question"} <ChevronRight size={18} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
