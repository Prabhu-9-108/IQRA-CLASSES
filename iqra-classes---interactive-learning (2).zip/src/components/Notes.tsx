import React, { useState } from 'react';
import { Download, Eye, Search } from 'lucide-react';

const NOTES_DATA = [
  { id: 'n1', class: 'Class 10', subject: 'Mathematics', title: 'Algebra Quick Notes', lang: 'English', date: '2025-07-01' },
  { id: 'n2', class: 'Class 12', subject: 'Physics', title: 'Electrostatics Summary', lang: 'English', date: '2025-08-10' },
  { id: 'n3', class: 'Class 9', subject: 'Social Science', title: 'Modern India Timeline', lang: 'Hindi', date: '2025-05-15' },
  { id: 'n4', class: 'Class 5', subject: 'Mathematics', title: 'Fractions & Decimals', lang: 'English', date: '2025-04-05' },
  { id: 'n5', class: 'Class 2', subject: 'English', title: 'Basic Grammar & Phonics', lang: 'English', date: '2025-03-18' },
];

export default function Notes() {
  const [filterClass, setFilterClass] = useState('');
  const [filterSubject, setFilterSubject] = useState('');

  const filteredNotes = NOTES_DATA.filter(note => 
    (!filterClass || note.class === filterClass) && 
    (!filterSubject || note.subject === filterSubject)
  );

  return (
    <div className="pt-24 pb-12 container mx-auto px-4">
      <header className="mb-12">
        <h1 className="text-3xl font-bold mb-2">Class-wise Notes</h1>
        <p className="text-[var(--neu-text-secondary)]">Concise, exam-focused notes aligned with Board syllabus.</p>
      </header>

      <div className="neu-card mb-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <label className="form-label">Filter by Class</label>
          <select 
            className="neu-input w-full" 
            value={filterClass} 
            onChange={(e) => setFilterClass(e.target.value)}
          >
            <option value="">All Classes</option>
            <option>Class 12</option>
            <option>Class 11</option>
            <option>Class 10</option>
            <option>Class 9</option>
            <option>Class 8</option>
            <option>Class 7</option>
            <option>Class 6</option>
            <option>Class 5</option>
            <option>Class 4</option>
            <option>Class 3</option>
            <option>Class 2</option>
          </select>
        </div>
        <div>
          <label className="form-label">Filter by Subject</label>
          <select 
            className="neu-input w-full" 
            value={filterSubject} 
            onChange={(e) => setFilterSubject(e.target.value)}
          >
            <option value="">All Subjects</option>
            <option>Mathematics</option>
            <option>Science</option>
            <option>Social Science</option>
            <option>English</option>
            <option>Hindi</option>
            <option>Sanskrit</option>
          </select>
        </div>
        <div className="flex items-end">
          <button className="neu-btn w-full flex items-center justify-center gap-2">
            <Search size={18} /> Search Notes
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredNotes.map((note) => (
          <div key={note.id} className="neu-card">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold">{note.title}</h3>
              <span className="bg-[var(--neu-bg-secondary)] px-2 py-1 rounded-lg text-xs font-bold shadow-[var(--neu-shadow-small)]">
                {note.class}
              </span>
            </div>
            <p className="text-sm text-[var(--neu-text-secondary)] mb-2">{note.subject} • {note.lang}</p>
            <p className="text-xs text-[var(--neu-text-secondary)] mb-6">Updated: {note.date}</p>
            <div className="flex gap-3">
              <button className="neu-btn neu-btn-primary flex-1 flex items-center justify-center gap-2 text-sm">
                <Download size={16} /> Download
              </button>
              <button className="neu-btn flex-1 flex items-center justify-center gap-2 text-sm">
                <Eye size={16} /> View
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
