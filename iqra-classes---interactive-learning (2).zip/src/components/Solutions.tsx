import React, { useState } from 'react';
import { Download, Eye, FileText } from 'lucide-react';

const SOLUTIONS_DATA = [
  { id: 's1', class: 'Class 12', subject: 'Mathematics', type: 'PYQ', year: 2024, title: 'Maths PYQ 2024 (Solved)', date: '2025-02-01' },
  { id: 's2', class: 'Class 10', subject: 'Science', type: 'Model', year: 2025, title: 'Science Model Paper (Solved)', date: '2025-01-12' },
  { id: 's3', class: 'Class 5', subject: 'EVS', type: 'Practice', year: 2025, title: 'EVS Practice Set 1', date: '2025-06-01' },
  { id: 's4', class: 'Class 8', subject: 'Hindi', type: 'PYQ', year: 2023, title: 'Hindi PYQ 2023 (Solved)', date: '2024-12-15' },
];

export default function Solutions() {
  const [filterType, setFilterType] = useState('');

  const filteredSolutions = SOLUTIONS_DATA.filter(sol => 
    !filterType || sol.type === filterType
  );

  return (
    <div className="pt-24 pb-12 container mx-auto px-4">
      <header className="mb-12">
        <h1 className="text-3xl font-bold mb-2">Solved Papers & Solutions</h1>
        <p className="text-[var(--neu-text-secondary)]">Previous years' papers, model papers, and practice sets.</p>
      </header>

      <div className="flex flex-wrap gap-4 mb-8">
        {['', 'PYQ', 'Model', 'Practice'].map((type) => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`neu-btn px-6 py-2 ${filterType === type ? 'shadow-[var(--neu-shadow-inset)] text-[var(--neu-accent)]' : ''}`}
          >
            {type || 'All Types'}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSolutions.map((sol) => (
          <div key={sol.id} className="neu-card">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold">{sol.title}</h3>
              <span className="bg-[var(--neu-bg-secondary)] px-2 py-1 rounded-lg text-xs font-bold shadow-[var(--neu-shadow-small)]">
                {sol.class}
              </span>
            </div>
            <div className="flex items-center gap-2 text-sm text-[var(--neu-text-secondary)] mb-4">
              <FileText size={16} />
              <span>{sol.subject} • {sol.type} • {sol.year}</span>
            </div>
            <p className="text-xs text-[var(--neu-text-secondary)] mb-6">Updated: {sol.date}</p>
            <div className="flex gap-3">
              <button className="neu-btn neu-btn-primary flex-1 flex items-center justify-center gap-2 text-sm">
                <Download size={16} /> Download
              </button>
              <button className="neu-btn flex-1 flex items-center justify-center gap-2 text-sm">
                <Eye size={16} /> View
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
