import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Sun, Moon, Menu, X } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function Navbar() {
  const [isDark, setIsDark] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const savedTheme = localStorage.getItem('iqra-theme');
    if (savedTheme === 'dark') {
      setIsDark(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = !isDark;
    setIsDark(newTheme);
    if (newTheme) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('iqra-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('iqra-theme', 'light');
    }
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Courses', path: '/#courses' },
    { name: 'Notes', path: '/notes' },
    { name: 'Solutions', path: '/solutions' },
    { name: 'Quiz', path: '/quiz' },
    { name: 'Contact', path: '/#contact' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[var(--neu-bg-primary)] shadow-[var(--neu-shadow-medium)] rounded-b-2xl px-4 py-3">
      <div className="container mx-auto flex items-center justify-between">
        <Link to="/" className="flex flex-col">
          <h2 className="text-[var(--neu-accent)] text-xl font-bold m-0">IQRA Classes</h2>
          <span className="text-[var(--neu-text-secondary)] text-xs font-medium">Excellence in Education</span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={cn(
                "nav-link px-3 py-2 rounded-xl transition-all duration-300 font-medium",
                location.pathname === link.path 
                  ? "text-[var(--neu-accent)] shadow-[var(--neu-shadow-inset)]" 
                  : "text-[var(--neu-text-primary)] hover:text-[var(--neu-accent)] hover:shadow-[var(--neu-shadow-small)]"
              )}
            >
              {link.name}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={toggleTheme}
            className="neu-btn p-2 flex items-center justify-center"
            aria-label="Toggle theme"
          >
            {isDark ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          
          <button className="hidden sm:block neu-btn text-sm">Login</button>
          <button className="hidden sm:block neu-btn neu-btn-primary text-sm">Sign Up</button>

          <button
            className="md:hidden neu-btn p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-[var(--neu-bg-primary)] shadow-[var(--neu-shadow-large)] rounded-b-2xl p-4 flex flex-col gap-2">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              onClick={() => setIsMenuOpen(false)}
              className={cn(
                "px-4 py-3 rounded-xl transition-all font-medium",
                location.pathname === link.path 
                  ? "text-[var(--neu-accent)] shadow-[var(--neu-shadow-inset)]" 
                  : "text-[var(--neu-text-primary)] hover:bg-[var(--neu-bg-secondary)]"
              )}
            >
              {link.name}
            </Link>
          ))}
          <div className="flex gap-2 mt-2">
            <button className="flex-1 neu-btn py-3">Login</button>
            <button className="flex-1 neu-btn neu-btn-primary py-3">Sign Up</button>
          </div>
        </div>
      )}
    </nav>
  );
}
